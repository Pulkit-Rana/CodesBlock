<script type="text/javascript">
    (function ($) {
        $(document).ready(function () {
            $('#custom_redirect_enabled').on('change', function () {
                if ($(this).is(':checked')) {
                    $('#redirect').css('display', '');
                } else {
                    $('#redirect').css('display', 'none');
                }
            });

            $('#custom_redirect_reg_enabled').on('change', function () {
                if ($(this).is(':checked')) {
                    $('#redirect_reg').css('display', '');
                } else {
                    $('#redirect_reg').css('display', 'none');
                }
            });

            $('#default_redirect_enabled').on('change', function () {
                if ($(this).is(':checked')) {
                    $('#default_redirect').css('display', '');
                } else {
                    $('#default_redirect').css('display', 'none');
                }
            });

            $('#default_redirect_reg_enabled').on('change', function () {
                if ($(this).is(':checked')) {
                    $('#default_redirect_reg').css('display', '');
                } else {
                    $('#default_redirect_reg').css('display', 'none');
                }
            });
        });
    })(jQuery);


    function nslPageAutocomplete(selector) {
        (function ($) {
            $(document).ready(function () {

                const field = $(selector);
                const hidden = $(field.data("target"));
                const clear = field.siblings(".nsl-autocomplete-clear");

                if (!field.length || !hidden.length) {
                    return;
                }

                function refreshClearButton() {
                    clear.toggle(!!hidden.val());
                }

                function setValid(id, text) {
                    hidden.val(id);
                    field.val(text);

                    field.data("valid-id", id);
                    field.data("valid-text", text);

                    refreshClearButton();
                }

                setValid(hidden.val(), field.val());

                const cache = {};
                field.autocomplete({
                    source: function (request, response) {

                        const term = request.term;

                        if (cache[term]) {
                            response(cache[term]);
                            return;
                        }

                        $.ajax({
                            url: ajaxurl,
                            dataType: "json",
                            data: {
                                action: field.data("action"),
                                term: term,
                                _ajax_nonce: field.data("nonce")
                            },
                            success: function (data) {
                                cache[term] = data;
                                response(data);
                            }
                        });
                    },
                    minLength: 0,
                    select: function (event, ui) {
                        setValid(ui.item.id, ui.item.value);
                        return false;
                    },
                    change: function () {
                        if (!hidden.val()) {
                            field.val(field.data("valid-text"));
                            hidden.val(field.data("valid-id"));
                        }
                    },
                    open: function () {
                        field.attr('aria-expanded', 'true');
                    },
                    close: function () {
                        field.attr('aria-expanded', 'false');
                    }
                });

                field.attr({
                    'role': 'listbox',
                    'aria-autocomplete': 'list',
                    'aria-expanded': 'false',
                    'aria-owns': field.autocomplete('widget').attr('id')
                })

                field.on("focus", function () {
                    if (!field.val()) {
                        field.autocomplete("search", "");
                    }
                });

                field.on("input", function () {
                    hidden.val("");
                    refreshClearButton();
                });

                clear.on("click", function () {
                    setValid("", "");
                    field.trigger("focus");
                });

                // Returns a jQuery object containing the menu element.
                field.autocomplete('widget')
                    .addClass('nsl-page-autocomplete')
                    .attr('role', 'listbox')
                    /*
                     * Looks like Safari and VoiceOver need an `aria-selected` attribute. See ticket #33301.
                     * The `menufocus` and `menublur` events are the same events used to add and remove
                     * the `ui-state-focus` CSS class on the menu items. See jQuery UI Menu Widget.
                     */
                    .on('menufocus', function (event, ui) {
                        ui.item.attr('aria-selected', 'true');
                    })
                    .on('menublur', function () {
                        // The `menublur` event returns an object where the item is `null`,
                        // so we need to find the active item with other means.
                        $(this).find('[aria-selected="true"]').removeAttr('aria-selected');
                    });

                refreshClearButton();
            });
        })(jQuery);
    }

    nslPageAutocomplete("#register-flow-page-search");
    nslPageAutocomplete("#oauth-redirect-uri-proxy-page-search");
</script>

<style>
    .nsl-autocomplete-wrap {
        position: relative;
        display: inline-block;
    }

    .nsl-autocomplete-wrap input[type="text"] {
        padding-right: 28px;
    }

    .nsl-autocomplete-clear {
        position: absolute;
        top: 50%;
        right: 6px;
        transform: translateY(-50%);

        border: 0;
        background: transparent;
        cursor: pointer;

        font-size: 18px;
        line-height: 1;

        color: #777;

        padding: 0;
        margin: 0;

        display: none;
    }

    .nsl-autocomplete-clear:hover {
        color: #000;
    }

    .nsl-page-autocomplete li:has(div.ui-state-active) {
        background-color: #1344FE;
        color: #FFF;
    }
</style>

<table class="form-table">
    <tbody>
    <tr>
        <th scope="row"><?php _e('Debug mode', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="debug"
                              value="0" <?php if ($settings->get('debug') == '0') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disabled', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="debug"
                              value="1" <?php if ($settings->get('debug') == '1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Enabled', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Bypass cache on redirect', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="bypass_cache"
                              value="0" <?php if ($settings->get('bypass_cache') == '0') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disabled', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="bypass_cache"
                              value="1" <?php if ($settings->get('bypass_cache') == '1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Enabled', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description" id="tagline-bypass_cache"><?php printf(__('Enabling this option will add a GET parameter to the URL where we redirect after a successful registration or login with social login. %1$sLearn more%2$s.', 'nextend-facebook-connect'), '<a href="https://social-login.nextendweb.com/documentation/getting-started/troubleshooting/bypass-cache-after-social-login/#bypass-cache-after-login" target="_blank">', '</a>'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Page for register flow', 'nextend-facebook-connect'); ?></th>
        <td>
            <?php
            $selectedRegisterFlowPage      = $settings->get('register-flow-page');
            $selectedRegisterFlowPageTitle = '';

            if ($selectedRegisterFlowPage) {
                $selectedRegisterFlowPageTitle = get_the_title($selectedRegisterFlowPage);
            }
            ?>
            <div class="nsl-autocomplete-wrap">
                <input type="hidden"
                       name="register-flow-page"
                       id="register-flow-page"
                       value="<?php echo esc_attr($selectedRegisterFlowPage); ?>">

                <input type="text"
                       id="register-flow-page-search"
                       value="<?php echo esc_attr($selectedRegisterFlowPageTitle); ?>"
                       placeholder="<?php esc_attr_e('None', 'nextend-facebook-connect'); ?>"
                       autocomplete="off"
                       data-target="#register-flow-page"
                       data-action="nsl_search_register_flow_pages"
                       data-nonce="<?php echo esc_attr(wp_create_nonce('nsl_search_register_flow_pages')); ?>">

                <button type="button"
                        class="nsl-autocomplete-clear"
                        aria-label="<?php esc_attr_e('Clear - Page for register flow', 'nextend-facebook-connect'); ?>">
                    &times;
                </button>
            </div>
            <p class="description" id="tagline-register-flow-page-1"><?php _e("This setting is used when you request additional data from the users (such as email address) and to display the Terms and conditions.", "nextend-facebook-connect"); ?></p>
            <p class="description" id="tagline-register-flow-page"><?php printf(__('%2$s First create a new page and insert the following shortcode: %1$s then select this page above', 'nextend-facebook-connect'), '<code>[nextend_social_login_register_flow]</code>', '<b>' . __("Usage:", "nextend-facebook-connect") . '</b>'); ?></p>
            <p class="description" id="tagline-register-flow-page"><?php printf(__('%1$s You won\'t be able to reach the selected page unless a social login/registration happens.', 'nextend-facebook-connect'), '<b>' . __("Important:", "nextend-facebook-connect") . '</b>'); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php _e('OAuth redirect uri proxy page', 'nextend-facebook-connect'); ?></th>
        <td>
            <?php

            $selectedOAuthProxyPage      = $settings->get('proxy-page');
            $selectedOAuthProxyPageTitle = '';

            if ($selectedOAuthProxyPage) {
                $selectedOAuthProxyPageTitle = get_the_title($selectedOAuthProxyPage);
            }
            ?>
            <div class="nsl-autocomplete-wrap">
                <input type="hidden"
                       name="proxy-page"
                       id="oauth-redirect-uri-proxy-page"
                       value="<?php echo esc_attr($selectedOAuthProxyPage); ?>">

                <input type="text"
                       id="oauth-redirect-uri-proxy-page-search"
                       value="<?php echo esc_attr($selectedOAuthProxyPageTitle); ?>"
                       placeholder="<?php esc_attr_e('None', 'nextend-facebook-connect'); ?>"
                       autocomplete="off"
                       data-target="#oauth-redirect-uri-proxy-page"
                       data-action="nsl_search_oauth_proxy_pages"
                       data-nonce="<?php echo esc_attr(wp_create_nonce('nsl_search_oauth_proxy_pages')); ?>">

                <button type="button"
                        class="nsl-autocomplete-clear"
                        aria-label="<?php esc_attr_e('Clear - OAuth redirect uri proxy page', 'nextend-facebook-connect'); ?>">
                    &times;
                </button>
            </div>

            <p class="description" id="tagline-proxy-page-1"><?php _e("You can use this setting when wp-login.php page is not available to handle the OAuth flow.", "nextend-facebook-connect") ?></p>
            <p class="description" id="tagline-register-flow-page"><?php printf(__('%1$s First create a new page then select this page above.', 'nextend-facebook-connect'), '<b>' . __("Usage:", "nextend-facebook-connect") . '</b>'); ?></p>
            <p class="description" id="tagline-register-flow-page"><?php printf(__('%1$s You won\'t be able to reach the selected page unless a social login/registration happens.', 'nextend-facebook-connect'), '<b>' . __("Important:", "nextend-facebook-connect") . '</b>'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><label
                    for="default_redirect"><?php _e('Prevent external redirect overrides', 'nextend-facebook-connect'); ?></label>
        </th>
        <td>
            <label for="redirect_prevent_external">
                <input type="hidden" name="redirect_prevent_external" value="0">
                <input type="checkbox" name="redirect_prevent_external" id="redirect_prevent_external" value="1"<?php if ($settings->get('redirect_prevent_external') == '1') : ?> checked="checked" <?php endif; ?>>
                <?php _e('Disable external redirects', 'nextend-facebook-connect'); ?>
            </label>
        </td>
    </tr>

    <tr>
        <th scope="row"><label
                    for="default_redirect"><?php _e('Default redirect url', 'nextend-facebook-connect'); ?></label>
        </th>
        <td>
            <?php
            $useDefault       = false;
            $default_redirect = $settings->get('default_redirect');
            if (!empty($default_redirect)) {
                $useDefault = true;
            }
            ?>
            <fieldset><label for="default_redirect_enabled">
                    <input name="default_redirect_enabled" type="checkbox" id="default_redirect_enabled"
                           value="1" <?php if ($useDefault): ?> checked<?php endif; ?>>
                    <?php _e('for Login', 'nextend-facebook-connect'); ?></label>
            </fieldset>
            <input name="default_redirect" type="text" id="default_redirect" value="<?php echo esc_attr($default_redirect); ?>"
                   class="regular-text"<?php if (!$useDefault): ?> style="display:none;"<?php endif; ?>>

            <?php
            $useDefault          = false;
            $default_redirectReg = $settings->get('default_redirect_reg');
            if (!empty($default_redirectReg)) {
                $useDefault = true;
            }
            ?>
            <fieldset><label for="default_redirect_reg_enabled">
                    <input name="default_redirect_reg_enabled" type="checkbox" id="default_redirect_reg_enabled"
                           value="1" <?php if ($useDefault): ?> checked<?php endif; ?>>
                    <?php _e('for Register', 'nextend-facebook-connect'); ?></label>
            </fieldset>
            <input name="default_redirect_reg" type="text" id="default_redirect_reg"
                   value="<?php echo esc_attr($default_redirectReg); ?>"
                   class="regular-text"<?php if (!$useDefault): ?> style="display:none;"<?php endif; ?>>
        </td>
    </tr>

    <tr>
        <th scope="row"><label
                    for="redirect"><?php _e('Fixed redirect url', 'nextend-facebook-connect'); ?></label>
        </th>
        <td>
            <?php
            $useCustom = false;
            $redirect  = $settings->get('redirect');
            if (!empty($redirect)) {
                $useCustom = true;
            }
            ?>
            <fieldset><label for="custom_redirect_enabled">
                    <input name="custom_redirect_enabled" type="checkbox" id="custom_redirect_enabled"
                           value="1" <?php if ($useCustom): ?> checked<?php endif; ?>>
                    <?php _e('for Login', 'nextend-facebook-connect'); ?></label>
            </fieldset>
            <input name="redirect" type="text" id="redirect" value="<?php echo esc_attr($redirect); ?>"
                   class="regular-text"<?php if (!$useCustom): ?> style="display:none;"<?php endif; ?>>

            <?php
            $useCustom   = false;
            $redirectReg = $settings->get('redirect_reg');
            if (!empty($redirectReg)) {
                $useCustom = true;
            }
            ?>
            <fieldset><label for="custom_redirect_reg_enabled">
                    <input name="custom_redirect_reg_enabled" type="checkbox" id="custom_redirect_reg_enabled"
                           value="1" <?php if ($useCustom): ?> checked<?php endif; ?>>
                    <?php _e('for Register', 'nextend-facebook-connect'); ?></label>
            </fieldset>
            <input name="redirect_reg" type="text" id="redirect_reg"
                   value="<?php echo esc_attr($redirectReg); ?>"
                   class="regular-text"<?php if (!$useCustom): ?> style="display:none;"<?php endif; ?>>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Blacklisted redirects', 'nextend-facebook-connect'); ?></th>
        <td>
            <?php
            $blacklistedUrls = $settings->get('blacklisted_urls');
            ?>
            <textarea rows="4" cols="53" name="blacklisted_urls" id="blacklisted_urls"><?php echo esc_textarea($blacklistedUrls); ?></textarea>
            <p class="description"><?php _e('If you want to blacklist redirect url params. One pattern per line.', 'nextend-facebook-connect'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Support login restrictions', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="login_restriction"
                              value="0" <?php if ($settings->get('login_restriction') == '0') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disabled', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="login_restriction"
                              value="1" <?php if ($settings->get('login_restriction') == '1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Enabled', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description" id="tagline-login-restriction"><?php printf(__('Please visit to our %1$s to check what plugins are supported!', 'nextend-facebook-connect'), '<a href="https://social-login.nextendweb.com/documentation/getting-started/troubleshooting/login-restrictions/" target="_blank">Login Restriction page</a>'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Display avatars in "All media items"', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="avatars_in_all_media"
                              value="0" <?php if ($settings->get('avatars_in_all_media') == '0') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disabled', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="avatars_in_all_media"
                              value="1" <?php if ($settings->get('avatars_in_all_media') == '1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Enabled', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description"><?php _e('Enabling this option can speed up loading images in Media Library - Grid view!', 'nextend-facebook-connect'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Membership', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="allow_register"
                              value="-1" <?php if ($settings->get('allow_register') == '-1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('WordPress default', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="allow_register"
                              value="0" <?php if ($settings->get('allow_register') == '0') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disabled', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="allow_register"
                              value="1" <?php if ($settings->get('allow_register') == '1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Enabled', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description"><?php _e('Allow registration with Social login.', 'nextend-facebook-connect'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Custom label for register buttons', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="custom_register_label"
                              value="0" <?php if ($settings->get('custom_register_label') == '0') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disabled', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="custom_register_label"
                              value="1" <?php if ($settings->get('custom_register_label') == '1') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Enabled', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description"><?php printf(__('Set a custom label for the social buttons in registration forms and for shortcodes with %1$s parameter set to %2$s.<br>The register specific labels can be modified at the Buttons tab of each provider.<br>This option also allows the use of register specific %3$s options.', 'nextend-facebook-connect'), '<b>labeltype</b>', '<b>register</b>', '<a href="https://social-login.nextendweb.com/documentation/form-integrations/custom-actions/" target="_blank">Custom Actions</a>'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Redirect overlay', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="redirect_overlay"
                              value="" <?php if ($settings->get('redirect_overlay') == '') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('No overlay', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="redirect_overlay"
                              value="overlay-only" <?php if ($settings->get('redirect_overlay') == 'overlay-only') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Display overlay', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="redirect_overlay"
                              value="overlay-with-spinner" <?php if ($settings->get('redirect_overlay') == 'overlay-with-spinner') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Display overlay with spinner', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="redirect_overlay"
                              value="overlay-with-spinner-and-message" <?php if ($settings->get('redirect_overlay') == 'overlay-with-spinner-and-message') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Display overlay with spinner and message', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description"><?php _e('You can display an overlay on your site when we start the redirect after the authentication.', 'nextend-facebook-connect'); ?></p>
            <p class="description"><?php printf(__('%1$s The overlay won\'t be displayed if the %2$s setting is set to %3$s!', 'nextend-facebook-connect'), '<b>' . __("Note:", "nextend-facebook-connect") . '</b>', '<b>' . __("Target window", "nextend-facebook-connect") . '</b>', '<b>' . __("Prefer same window", "nextend-facebook-connect") . '</b>'); ?></p>
        </td>
    </tr>

    <tr>
        <th scope="row"><?php _e('Unsupported WebView behavior', 'nextend-facebook-connect'); ?></th>
        <td>
            <fieldset>
                <label><input type="radio" name="unsupported_webview_behavior"
                              value="" <?php if ($settings->get('unsupported_webview_behavior') == '') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Remove button', 'nextend-facebook-connect'); ?></span></label><br>
                <label><input type="radio" name="unsupported_webview_behavior"
                              value="disable-button" <?php if ($settings->get('unsupported_webview_behavior') == 'disable-button') : ?> checked="checked" <?php endif; ?>>
                    <span><?php _e('Disable button', 'nextend-facebook-connect'); ?></span></label><br>
            </fieldset>
            <p class="description"><?php printf(__('Some %1$sproviders%2$s don\'t support embedded browsers.', 'nextend-facebook-connect'), '<a href="https://social-login.nextendweb.com/documentation/getting-started/troubleshooting/missing-social-login-on-mobile/" target="_blank">', '</a>'); ?></p>
            <p class="description"><?php printf(__('This setting defines if we should remove or disable the related buttons in WebView environments.', 'nextend-facebook-connect'), '<a href="https://social-login.nextendweb.com/documentation/getting-started/troubleshooting/missing-social-login-on-mobile/" target="_blank">', '</a>'); ?></p>
        </td>
    </tr>

    </tbody>
</table>

<?php
include dirname(__FILE__) . '/general-pro.php';
?>