<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
namespace Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions;

/**
 * Class to manage a 403 - Forbidden response.
 */
class Forbidden_Exception extends Remote_Request_Exception {

}
